#include <stdio.h>

main(int argc, char **argv){
   /* Was it the right number of parameters? */
   if(argc != 2){
      fprintf(stdout,"Usage: %s PARAMETER\n",argv[0]);
      exit(1);
   }
   /* OK, display the parameter! */
   display_stuff(argv[1]);
}

/* Function called from main(), used to display the parameter */
int display_stuff(char *parameter){

   /* copy_of_parameter is a buffer of 256 bytes */
   char copy_of_parameter[80];

   /* This means copy_of_parameter=parameter */
   /* And yes, this is very insecure */
   strcpy(copy_of_parameter,parameter);

   /* Print out the parameter! */
   printf("The parameter was: %s\n",copy_of_parameter);
}


