<HTML>
    <HEAD>
        <TITLE> A really simple message board </TITLE> 
        <META http-equiv="Content-Type" content="text/html; 
              charset=UNICODE-1-1-UTF-7">
    </HEAD>

    <BODY>

<H1> Welcome to my message board! </H1>
Introduce your comment here!

<FORM ACTION="message_board.php" METHOD=GET>
    <INPUT TYPE="TEXT" NAME="name"> <BR>
    <TEXTAREA NAME="comments" rows="8" cols="40"> </TEXTAREA>
    <INPUT TYPE="SUBMIT" VALUE="Send the comment!">
</FORM>
<?
    ##################################
    # A new comment has been entered?
    ##################################
    $name=$_GET['name'];
    $comments=$_GET['comments'];

    if($name != ""){
        $fp=fopen("comments.html","a");
        fwrite($fp, "FROM: ".htmlentities($name).
            "<BR> COMMENT:<BR>".htmlentities($comments)."<BR><HR>\n");

        fclose($fp);

        print("<BR>\n");
        print("Thanks for your comment! Here is your comment: <BR>\n");
        print("FROM: ".htmlentities($name).
              "<BR> COMMENT:<BR>".htmlentities($comments)." <BR>\n");
    } 
?>
Here is what people before you wrote:
<HR>
<?
    $fp=fopen("comments.html","r");
    $existing_comments=fread($fp, filesize("comments.html") );
    fclose($fp);
    print("$existing_comments");

?>
</BODY>
</HTML>

