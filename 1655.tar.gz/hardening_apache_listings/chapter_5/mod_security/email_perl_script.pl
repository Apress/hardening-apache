#!/usr/bin/perl
$subject = "[mod_security] Web attack";
$sendmail = "/usr/lib/sendmail -t";
$to = "your\@email_here.com";
$body = "";

foreach $var (sort(keys(%ENV))) {
     $val = $ENV{$var};
     $val =~ s|\n|\\n|g;
     $val =~ s|"|\\"|g;

     $body = $body . "${var}=\"${val}\"\n";
     #print "${var}=\"${val}\"\n";
}
open(EMAIL, "|$sendmail");
print EMAIL "To: $to\n";
print EMAIL "Subject: $subject\n";
print EMAIL "Content-Type: text/plain\n\n";
print EMAIL $body;
close(EMAIL);

