/* 
You should use this program if your system has an old (not GNU)
"date" utility which doesn't support date '+%s'.
To compile it, just type:

cc -o seconds seconds.c

And copy "seconds" into /usr/local/bin (or any other bin directory in the PATH):

# cp seconds /usr/local/bin

Then, you can use "seconds" instead of "date '+%s'" in your scripts.
*/
#include <stdio.h>
#include <time.h>
main(){
	time_t t;
	t=time(NULL);
	printf("%d",t);
}
